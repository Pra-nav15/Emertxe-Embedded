/* 
 * File:   time_seperator.h
 * Author: PRANAV
 *
 * Created on February 6, 2026, 8:46 AM
 */

#ifndef TIME_SEPERATOR_H
#define	TIME_SEPERATOR_H

void init_timer0(void);
void init_timer1(void);
void init_timer2(void);
void init_led_config(void);

#endif	/* TIME_SEPERATOR_H */

