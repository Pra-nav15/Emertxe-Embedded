#ifndef MAIN_H
#define MAIN_H

#define EDGE         0
#define LEVEL        1

#define ON           1
#define OFF          0
#define LED1         RB0


 static void init_config(void);
  
#endif