/*
 * File:   isr.c
 * Author: PRANAV
 *
 * Created on February 10, 2026, 9:42 AM
 */

#include <xc.h>
#include"ssd_display.h"

unsigned int idle_count=0;
volatile unsigned int half_sec_flag =0;
volatile unsigned int one_sec_flag =0;

void __interrupt() isr(void)
{ 
    if(TMR0IF == 1)
    {
        TMR0IF=0;
        idle_count++;
        if(idle_count == 10000)
        {
            half_sec_flag=1;
        }
        if(idle_count == 20000)
        {
            one_sec_flag=1;
            idle_count=0;
        }
        TMR0=TMR0+8;
    }
}