/*
 * File:   main.c
 * Author: PRANAV
 *
 * Created on February 10, 2026, 8:57 AM
 */



#include <xc.h>
#include "ssd_display.h"

volatile unsigned int half_sec_flag;
volatile unsigned int one_sec_flag;

static unsigned char ssd[SSD_COUNT];
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
static void init_config(void)
{
    init_ssd_display();
    init_timer0();
}

void main(void)
{
    init_config();
    unsigned char hour = 12;
    unsigned char minutes = 0;
    unsigned char dp_flag = 0;
    while(1)
    {
        if(half_sec_flag == 1)
        {
            half_sec_flag = 0;
            dp_flag = dp_flag ^ 0x01;
        }
        if(one_sec_flag == 1)
        {
            one_sec_flag = 0;
            minutes++;
            if(minutes>60)
            {
                minutes=0;
                hour++;
            }
            if(hour>24)
            {
                hour=0;
            }
        }
        ssd[0] = digit[minutes % 10];
        ssd[1] = digit[(minutes / 10) % 10];
        ssd[2] = digit[hour % 10];
        if (dp_flag)
        {
           ssd[2] = ssd[2] | 0x10;  
        }
        ssd[3] = digit[(hour / 10) % 10];
        display(ssd);
    }
}

