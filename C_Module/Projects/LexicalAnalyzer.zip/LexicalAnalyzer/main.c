#include <stdio.h>
#include "lexer.h"

int main(int argc, char* argv[])
{
    if(argc < 2)									
	{
		printf("Insufficient Number of Arguments\n");
		printf("Usage: ./a.out <sample.c file>\n");		
		return 0;
	}
	initializeLexer(argv);
	Token token;
	while ((token = getNextToken()).type != UNKNOWN)
	{
		printf("Token: %s, Type: %d\n", token.lexi, token.type);
    }
    printf("Success");
    return 0;
}