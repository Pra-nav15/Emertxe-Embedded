/*
                                  Project Documentation
Name: Pranav Prasad
Date: 21/09/2025
Description:
• This project is an AddressBook System made in C.
• It helps users to add, view, search, edit, store and delete contacts easily.
• Each contact has three details: name, mobile number, and email.
• In the Create contacts we can create a new contact by entering the name,mobilenumber and email id followed by certain validations
• In the Search contacts we can search the contacts by name,mobilenumber and mail id,each parameter has a seperate function called within Search contacts it also has some validation
• In the Search contacts search is done by comparing the entered parameter and the available details of the contacts.
• In the Edit contacts we can edit the contacts by name,mobilenumber and mail id and all the fields,edit can be done only by means of search of name,mobilenumber and mail id
• In the Edit contacts edit can be done by overwriting the entered parameter to the parameter of the available contact using string copy.
• In the Delete contacts we can delete the contacts by name,mobilenumber and mail id and all the fields,delete can be done only by means of search of name,mobilenumber and mail id
• In the Delete contacts delete is done by shifting the contact to last and decrementing the contact count
• In the Display contacts we can display the contact details with name,mobilenumber and mail id as a table and also total contact count.
• In the Save contacts it should save(write) the entire contacts upon save to a .txt file and also Load contacts function to read the contact details from the file even after the program recompilation
*/
#include<stdio.h>
#include "contact.h"
int main()
{
    /* Variable and structre defintion */
    int option;
    AddressBook addressbook;
    addressbook.contact_count = 0;
    load_contacts(&addressbook);// call only once when the program starts

    // init_intitalization(&addressbook);

    while (1)
    {
        printf("\033[0;34m\n=============Address Book=============\033[0m\n"); /* Give a prompt message for a user */
        printf("\033[0;35m1.Add contact\n2.Search contact\n3.Edit contact\n4.Delete contact\n5.Display contact\n6.Save contact\n7.Save and Exit\033[0m\n");
        printf("\033[0;33mEnter the option : \033[0m");
        scanf("%d", &option);
        switch (option) /* Based on choosed option */
        {
        case 1:
        {
            create_contact(&addressbook);// pass by reference is used here because we want to modify the original structure in the given location
            break;
        }
        case 2:
        {
            printf("\033[0;35mSearch Contact menu : \n1.Name \n2.Mobile number\n3.Mail ID\n4.Exit\nEnter the option : \033[0m"); /* Providing menu */
            search_contacts(&addressbook);
            break;
        }
        case 3:
            printf("\033[0;35mEdit Contact menu : \n1.Search By Name to edit\n2.Search By Mobile number to edit\n3.Search By Mail ID to edit\n4.Exit\nEnter the option : \033[0m"); /* Providing menu */
            edit_contact(&addressbook);
            break;

        case 4:
        {
            printf("\033[0;35mDelete Contact menu : \n1.Search By Name to delete\n2.Search By Mobile number to delete\n3.Search By Mail ID to delete\n4.Exit\nEnter the option : \033[0m"); /* Providing menu */
            delete_contact(&addressbook);
            break;
        }
        case 5:
        {
            printf("\033[0;36mList Contacts\033[0m\n");
            list_contacts(&addressbook);
            break;
        }

        case 6:
            printf("\033[0;36mSaving contacts...\033[0m\n");
            save_contacts(&addressbook);
            break;

        case 7:
            printf("\033[0;36mINFO : Save and Exit...\033[0m\n");
            save_contacts(&addressbook);
            return 0;

        default:
            printf("\033[0;31mInvalid option\033[0m\n");
            break;
        }
    }
    return 0;
}
