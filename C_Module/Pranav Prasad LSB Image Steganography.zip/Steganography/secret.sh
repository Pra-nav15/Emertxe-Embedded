#!/bin/bash
echo "Rohit and Virat"
