#include <stdio.h>
void greet() {
    printf("Hello from helper!\n");
}