#include <stdio.h>
void print() {
    printf("Rohit and Virat!\n");
}