#include "invsearch.h"

int read_and_validate(int argc, char* argv[], filenames_t** head)
{
    int flag;
    if (argc < 2)
    {
        printf("ERROR ! --> Usage: ./a.out file1.txt file2.txt");
        return FAILURE;
    }
    for (int i = 1; i < argc; i++)
    {
        if (open_files(argv[i]) == SUCCESS)
        {
            filenames_t* temp = *head;
            flag = 0;
            while (temp != NULL) //traverse until last
            {
                if (strcmp(temp->file_name, argv[i]) == 0) //duplicate check
                {
                    printf("Duplicate Found: %s\n", argv[i]);
                    flag = 1;
                    break;
                }
                temp = temp->f_link;
            }
            if (flag == 0)
            {
                filenames_t* new = malloc(sizeof(filenames_t));
                strcpy(new->file_name, argv[i]);
                new->f_link = *head;
                *head = new;
            }
        }
        else
        {
            printf("Error !; Files Cannot be opened\n");
            return FAILURE;
        }
    }
    return SUCCESS;
}

int open_files(char* argv)
{
    char* exten = strrchr(argv, '.');
    if (exten != NULL  && strcmp(exten, ".txt") == 0)
    {
        FILE *fptr = fopen(argv, "r");
        if (fptr != NULL)
        {
            fseek(fptr, 0, SEEK_END);
            if (ftell(fptr) <= 0) //empty file
            {
                return FAILURE;
            }
            else //file has some contents
            {
                return SUCCESS;
            }
        }
        else
        {
            printf("Error in Opening the File\n");
            return FAILURE;
        }
    }
}