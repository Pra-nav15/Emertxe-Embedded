#include "invsearch.h"

int display_database(hashtable_t* hash_arr)
{
    if (hash_arr == NULL)
    {
        return FAILURE;
    }
    printf("%-6s %-10s %-15s %-15s %-10s\n", "Index", "FileCount", "Word","File Name","Word Count");
    for (int i = 0;i < 28;i++)
    {
        if (hash_arr[i].h_link != NULL)
        {
            mainnode_t* main_temp = hash_arr[i].h_link;
            while (main_temp != NULL)
            {
                printf("%-6d %-10d %-15s", i, main_temp->file_count, main_temp->word);
                subnode_t* sub_temp = main_temp->s_link;
                while (sub_temp != NULL)
                {
                    printf("%-15s %-10d\n", sub_temp->file_name, sub_temp->word_count);
                    sub_temp = sub_temp->s_link;
                }
                main_temp = main_temp->m_link;
            }
        }
    }
    return SUCCESS;
}