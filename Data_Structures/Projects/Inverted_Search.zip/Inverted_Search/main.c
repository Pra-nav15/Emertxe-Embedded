#include "invsearch.h"

int main(int argc, char* argv[])
{
    filenames_t* head = NULL;
    db_status status = DATABASE_EMPTY;
    hashtable_t hash_table[28];
    for (int i = 0;i < 28;i++)
    {
        hash_table[i].index = i;
        hash_table[i].h_link = NULL;
    }
    if (read_and_validate(argc, argv, &head) == FAILURE)
    {
        return FAILURE;
    }
    int choice;
    while (1)
    {
        printf("1.Create Database\n2.Display Database\n3.Search Database\n4.Update Database\n5.Save Database\n6.Exit\nEnter the Choice : ");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            if (status != DATABASE_EMPTY)
            {
                printf("Database already created\n");
            }
            else
            {
                if (create_database(head, hash_table) == SUCCESS)
                {
                    printf("Database created\n");
                    status = DATABASE_CREATED;
                }
            }
            break;
        case 2:
            if (display_database(hash_table) != SUCCESS)
            {
                printf("Nothing to Display in Database");
            }
            break;
        case 3:
            if (status == DATABASE_EMPTY)
            {
                printf("Database is Empty\n");
            }
            else
            {
                char search_word[WORD_SIZE];
                printf("Enter Word to Search: ");
                scanf("%s", search_word);
                if (search_database(hash_table, search_word) == DATA_NOT_FOUND)
                {
                    printf("Word Not Found in Database\n");
                }
            }
            break;
        case 4:
            
            break;
        case 5:
            if (save_database(hash_table) == SUCCESS)
            {
                printf("DataBase Saved Successfully\n");
            }
            else
            {
                printf("Failed to save Database\n");
            }
            break;
        case 6:
            return EXIT;
            break;
        default:
            printf("Invalid Choice Entered,Try Again\n");
        }
    }
}