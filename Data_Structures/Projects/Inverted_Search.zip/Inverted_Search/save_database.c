#include "invsearch.h"

int save_database(hashtable_t *hash_arr)
{
    if (hash_arr == NULL)
    {
        return FAILURE;
    }
    char database[15];
    printf("Enter the database name: ");
    scanf("%s",database);   
    FILE *fp = fopen(database, "w");
    if (fp == NULL)
    {
        return FAILURE;
    }
    for (int i = 0; i < 28; i++) 
    {
        if (hash_arr[i].h_link != NULL)
        {
            mainnode_t *main_temp = hash_arr[i].h_link;
            while (main_temp != NULL)
            {
                fprintf(fp, "#%d %s %d", i, main_temp->word, main_temp->file_count);
                subnode_t *sub_temp = main_temp->s_link;
                while (sub_temp != NULL)
                {
                    fprintf(fp, "%s %d",sub_temp->file_name, sub_temp->word_count);
                    sub_temp = sub_temp->s_link;
                }
                fprintf(fp, "#\n");
                main_temp = main_temp->m_link;
            }
        }
    }

    fclose(fp);
    return SUCCESS;
}