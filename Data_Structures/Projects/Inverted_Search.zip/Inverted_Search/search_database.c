#include "invsearch.h"

int search_database(hashtable_t* hash_arr, char* word)
{
    if (hash_arr == NULL)
    {
        return FAILURE;
    }
    int index = hash_index(word[0]);
    mainnode_t* main_temp = hash_arr[index].h_link;
    while (main_temp != NULL)
    {
        if (strcmp(main_temp->word, word) == 0)
        {
            printf("This Word is found in %d files\n", main_temp->file_count);
            subnode_t* sub_temp = main_temp->s_link;
            while (sub_temp != NULL)
            {
                printf("File Name is %s\n", sub_temp->file_name);
                printf("Word Count is %d\n", sub_temp->word_count);
                sub_temp = sub_temp->s_link; 
            }
            return SUCCESS;
        }
        else
        {
            main_temp = main_temp->m_link;
        }
    }
    return DATA_NOT_FOUND;
}